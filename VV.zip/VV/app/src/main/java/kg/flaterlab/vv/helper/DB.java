package kg.flaterlab.vv.helper;


public class DB {

    public final static String USER_NODE = "user";

}
