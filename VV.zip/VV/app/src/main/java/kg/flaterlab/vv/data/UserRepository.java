package kg.flaterlab.vv.data;

public class UserRepository {

}
